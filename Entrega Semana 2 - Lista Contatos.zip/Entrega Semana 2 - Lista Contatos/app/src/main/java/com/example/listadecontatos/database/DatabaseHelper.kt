package com.example.listadecontatos.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE, null, VERSION) {

    companion object {
        const val DATABASE = "lista_contatos.db"
        const val VERSION = 1
        const val TABLE_CONTATOS = "contatos"
        const val COL_ID = "id"
        const val COL_NOME = "nome"
        const val COL_TELEFONE = "telefone"
        const val COL_EMAIL = "email"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val sql = "CREATE TABLE IF NOT EXISTS $TABLE_CONTATOS (" +
                "$COL_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "$COL_NOME VARCHAR(100)," +
                "$COL_TELEFONE VARCHAR(20)," +
                "$COL_EMAIL VARCHAR(100)" +
                ");"
        try {
            db?.execSQL(sql)
            Log.i("DatabaseHelper", "Tabela de contatos criada com sucesso!")
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Erro ao criar a tabela de contatos", e)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }
}
