package com.example.listadecontatos

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.listadecontatos.adapter.ContatoAdapter
import com.example.listadecontatos.database.ContatoDAO
import com.example.listadecontatos.databinding.ActivityMainBinding
import com.example.listadecontatos.model.Contato

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var contatoAdapter: ContatoAdapter
    private lateinit var contatoDAO: ContatoDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        contatoDAO = ContatoDAO(this)

        binding.fabAdicionar.setOnClickListener {
            val intent = Intent(this, FormContatoActivity::class.java)
            startActivity(intent)
        }

        configurarRecyclerView()
    }

    override fun onStart() {
        super.onStart()
        atualizarListaContatos()
    }

    private fun configurarRecyclerView() {
        contatoAdapter = ContatoAdapter(
            { id -> confirmarExclusao(id) },
            { contato -> editarContato(contato) }
        )

        binding.rvContatos.adapter = contatoAdapter
        binding.rvContatos.layoutManager = LinearLayoutManager(this)
    }

    private fun atualizarListaContatos() {
        val listaContatos = contatoDAO.listar()
        contatoAdapter.adicionarLista(listaContatos)
    }

    private fun confirmarExclusao(id: Int) {
        AlertDialog.Builder(this)
            .setTitle("Confirmação")
            .setMessage("Deseja realmente excluir este contato?")
            .setPositiveButton("Sim") { _, _ ->
                if (contatoDAO.deletar(id)) {
                    atualizarListaContatos()
                    Toast.makeText(this, "Contato excluído com sucesso!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Erro ao excluir contato!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Não", null)
            .show()
    }

    private fun editarContato(contato: Contato) {
        val intent = Intent(this, FormContatoActivity::class.java)
        intent.putExtra("contato", contato)
        startActivity(intent)
    }
}
