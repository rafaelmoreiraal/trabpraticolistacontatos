package com.example.listadecontatos.model

data class Contato(
    val id: Int = -1,
    val nome: String,
    val telefone: String,
    val email: String
)
