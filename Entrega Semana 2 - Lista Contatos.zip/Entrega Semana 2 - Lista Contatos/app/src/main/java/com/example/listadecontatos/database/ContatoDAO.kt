package com.example.listadecontatos.database

import android.content.ContentValues
import android.content.Context
import android.util.Log
import com.example.listadecontatos.model.Contato

class ContatoDAO(context: Context) : iContato {

    private val escrita = DatabaseHelper(context).writableDatabase
    private val leitura = DatabaseHelper(context).readableDatabase

    override fun inserir(contato: Contato): Boolean {
        val valores = ContentValues()
        valores.put(DatabaseHelper.COL_NOME, contato.nome)
        valores.put(DatabaseHelper.COL_TELEFONE, contato.telefone)
        valores.put(DatabaseHelper.COL_EMAIL, contato.email)

        try {
            escrita.insert(DatabaseHelper.TABLE_CONTATOS, null, valores)
            Log.i("ContatoDAO", "Contato inserido com sucesso!")
        } catch (e: Exception) {
            Log.e("ContatoDAO", "Erro ao inserir contato: ${e.message}")
            return false
        }
        return true
    }

    override fun atualizar(contato: Contato): Boolean {
        val valores = ContentValues()
        valores.put(DatabaseHelper.COL_NOME, contato.nome)
        valores.put(DatabaseHelper.COL_TELEFONE, contato.telefone)
        valores.put(DatabaseHelper.COL_EMAIL, contato.email)

        val args = arrayOf(contato.id.toString())

        try {
            escrita.update(DatabaseHelper.TABLE_CONTATOS, valores, "${DatabaseHelper.COL_ID} = ?", args)
            Log.i("ContatoDAO", "Contato atualizado com sucesso!")
        } catch (e: Exception) {
            Log.e("ContatoDAO", "Erro ao atualizar contato: ${e.message}")
            return false
        }
        return true
    }

    override fun deletar(id: Int): Boolean {
        val args = arrayOf(id.toString())
        try {
            escrita.delete(DatabaseHelper.TABLE_CONTATOS, "${DatabaseHelper.COL_ID} = ?", args)
            Log.i("ContatoDAO", "Contato deletado com sucesso!")
        } catch (e: Exception) {
            Log.e("ContatoDAO", "Erro ao deletar contato: ${e.message}")
            return false
        }
        return true
    }

    override fun listar(): List<Contato> {
        val listaContatos = mutableListOf<Contato>()

        val sql = "SELECT * FROM ${DatabaseHelper.TABLE_CONTATOS};"
        val cursor = leitura.rawQuery(sql, null)

        val indiceId = cursor.getColumnIndex(DatabaseHelper.COL_ID)
        val indiceNome = cursor.getColumnIndex(DatabaseHelper.COL_NOME)
        val indiceTelefone = cursor.getColumnIndex(DatabaseHelper.COL_TELEFONE)
        val indiceEmail = cursor.getColumnIndex(DatabaseHelper.COL_EMAIL)

        while (cursor.moveToNext()) {
            val id = cursor.getInt(indiceId)
            val nome = cursor.getString(indiceNome)
            val telefone = cursor.getString(indiceTelefone)
            val email = cursor.getString(indiceEmail)

            listaContatos.add(Contato(id, nome, telefone, email))
        }

        cursor.close()
        return listaContatos
    }
}
