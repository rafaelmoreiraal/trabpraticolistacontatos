package com.example.listadecontatos.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.listadecontatos.databinding.ItemListBinding
import com.example.listadecontatos.model.Contato

class ContatoAdapter(
    private val onClickExcluir: (Int) -> Unit,
    private val onClickEditar: (Contato) -> Unit
) : RecyclerView.Adapter<ContatoAdapter.ContatoViewHolder>() {

    private var listaContatos = emptyList<Contato>()

    fun adicionarLista(lista: List<Contato>) {
        this.listaContatos = lista
        notifyDataSetChanged()
    }

    inner class ContatoViewHolder(private val binding: ItemListBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(contato: Contato) {
            binding.textNome.text = contato.nome
            binding.textTelefone.text = contato.telefone

            binding.btnExcluir.setOnClickListener {
                onClickExcluir(contato.id)
            }

            binding.btnEditar.setOnClickListener {
                onClickEditar(contato)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContatoViewHolder {
        val binding = ItemListBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ContatoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContatoViewHolder, position: Int) {
        val contato = listaContatos[position]
        holder.bind(contato)
    }

    override fun getItemCount(): Int {
        return listaContatos.size
    }
}
