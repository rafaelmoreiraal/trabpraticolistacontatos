package com.example.listadecontatos

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.listadecontatos.database.ContatoDAO
import com.example.listadecontatos.databinding.ActivityFormContatoBinding
import com.example.listadecontatos.model.Contato

class FormContatoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFormContatoBinding
    private lateinit var contatoDAO: ContatoDAO
    private var contatoAtual: Contato? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFormContatoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        contatoDAO = ContatoDAO(this)

        val bundle = intent.extras
        if (bundle != null) {
            contatoAtual = bundle.getSerializable("contato") as Contato
            binding.editNome.setText(contatoAtual?.nome)
            binding.editTelefone.setText(contatoAtual?.telefone)
            binding.editEmail.setText(contatoAtual?.email)
        }

        binding.btnSalvar.setOnClickListener {
            salvarContato()
        }

        binding.btnCancelar.setOnClickListener {
            finish()
        }
    }

    private fun salvarContato() {
        val nome = binding.editNome.text.toString()
        val telefone = binding.editTelefone.text.toString()
        val email = binding.editEmail.text.toString()

        if (nome.isEmpty() || telefone.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            return
        }

        val contato = Contato(
            id = contatoAtual?.id ?: -1,
            nome = nome,
            telefone = telefone,
            email = email
        )

        if (contatoAtual == null) {

            if (contatoDAO.inserir(contato)) {
                Toast.makeText(this, "Contato salvo com sucesso!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Erro ao salvar contato!", Toast.LENGTH_SHORT).show()
            }
        } else {

            if (contatoDAO.atualizar(contato)) {
                Toast.makeText(this, "Contato atualizado com sucesso!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Erro ao atualizar contato!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
